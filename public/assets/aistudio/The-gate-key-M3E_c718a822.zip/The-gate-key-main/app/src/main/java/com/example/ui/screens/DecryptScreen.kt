@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class, ExperimentalLayoutApi::class)

package com.example.ui.screens

import android.net.Uri
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.FileOpen
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.SaveAlt
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.crypto.ContainerConstants
import com.example.ui.DecryptAuthMode
import com.example.ui.VaultViewModel
import com.example.ui.components.BannerKind
import com.example.ui.components.InfoChip
import com.example.ui.components.KeyValueRow
import com.example.ui.components.OperationProgressCard
import com.example.ui.components.RadioOptionRow
import com.example.ui.components.ResultCard
import com.example.ui.components.ScreenWithActionBar
import com.example.ui.components.SecretTextField
import com.example.ui.components.SectionHeader
import com.example.ui.components.ShapeBadge
import com.example.ui.components.StatusBanner
import com.example.ui.components.VaultButton
import com.example.ui.components.VaultTonalButton
import com.example.ui.components.connectedShape
import com.example.ui.components.staggeredEntrance
import com.example.ui.theme.VaultTheme
import com.example.ui.theme.emphasized

@Composable
fun DecryptScreen(
    viewModel: VaultViewModel,
    contentPadding: PaddingValues,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val motion = MaterialTheme.motionScheme
    val ext = VaultTheme.colors

    val containerUri by viewModel.decryptContainerUri.collectAsStateWithLifecycle()
    val inspectedHeader by viewModel.inspectedHeader.collectAsStateWithLifecycle()
    val inspectedEnvelopes by viewModel.inspectedEnvelopes.collectAsStateWithLifecycle()
    val authMode by viewModel.decryptAuthMode.collectAsStateWithLifecycle()
    val credentialInput by viewModel.decryptCredentialInput.collectAsStateWithLifecycle()
    val recoverySecretInput by viewModel.decryptRecoverySecretInput.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val progressFraction by viewModel.progressFraction.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val currentChunk by viewModel.currentChunk.collectAsStateWithLifecycle()
    val bytesProcessed by viewModel.bytesProcessed.collectAsStateWithLifecycle()
    val totalBytes by viewModel.totalBytes.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()
    val decryptedResult by viewModel.decryptedResult.collectAsStateWithLifecycle()

    val containerPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        viewModel.setDecryptContainerUri(uri)
    }
    val saveFileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { destinationUri: Uri? ->
        val result = decryptedResult
        if (destinationUri != null && result != null) {
            viewModel.saveResultToDestinationUri(result.decryptedTempFile, destinationUri)
        }
    }

    val header = inspectedHeader
    val listState = rememberLazyListState()
    LaunchedEffect(errorMessage) {
        if (errorMessage != null) {
            haptic.performHapticFeedback(HapticFeedbackType.Reject)
            listState.animateScrollToItem(listState.layoutInfo.totalItemsCount.coerceAtLeast(1) - 1)
        }
    }
    LaunchedEffect(decryptedResult) {
        if (decryptedResult != null) {
            haptic.performHapticFeedback(HapticFeedbackType.Confirm)
            listState.animateScrollToItem(listState.layoutInfo.totalItemsCount.coerceAtLeast(1) - 1)
        }
    }

    val canDecrypt = containerUri != null &&
        header != null &&
        !isProcessing &&
        (authMode != DecryptAuthMode.CUSTOM_CREDENTIAL || credentialInput.isNotEmpty()) &&
        (authMode != DecryptAuthMode.RECOVERY_SECRET || recoverySecretInput.isNotEmpty())

    ScreenWithActionBar(
        contentPadding = contentPadding,
        modifier = modifier,
        actionBar = {
            OperationProgressCard(
                isProcessing = isProcessing,
                progress = progressFraction,
                statusMessage = statusMessage,
                currentChunk = currentChunk,
                bytesProcessed = bytesProcessed,
                totalBytes = totalBytes,
                onCancel = { viewModel.cancelOperation() }
            )
            AnimatedVisibility(
                visible = !isProcessing,
                enter = expandVertically(motion.defaultSpatialSpec()) + fadeIn(motion.defaultEffectsSpec()),
                exit = shrinkVertically(motion.fastSpatialSpec()) + fadeOut(motion.fastEffectsSpec())
            ) {
                VaultButton(
                    text = "Decrypt & verify container",
                    icon = Icons.Rounded.LockOpen,
                    enabled = canDecrypt,
                    onClick = { viewModel.startDecryption() },
                    modifier = Modifier.fillMaxWidth().testTag("start_decryption_button")
                )
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = padding,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 1 ─ Container picker
            item(key = "picker") {
                Column(Modifier.staggeredEntrance(0), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SectionHeader("Encrypted file", step = 1, subtitle = "Choose an .adsky container.")
                    Surface(
                        Modifier.fillMaxWidth().testTag("decrypt_container_card"),
                        shape = RoundedCornerShape(32.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh
                    ) {
                        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ShapeBadge(
                                    icon = if (containerUri != null) Icons.Rounded.Check else Icons.Rounded.FileOpen,
                                    polygon = if (containerUri != null) MaterialShapes.Cookie9Sided else MaterialShapes.Sunny,
                                    size = 56.dp,
                                    containerColor = if (containerUri != null) ext.success else MaterialTheme.colorScheme.surfaceContainerHighest,
                                    contentColor = if (containerUri != null) ext.onSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.width(16.dp))
                                Text(
                                    if (containerUri != null) "Container selected" else "No container selected",
                                    style = MaterialTheme.typography.titleMedium.emphasized(),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            VaultTonalButton(
                                text = if (containerUri == null) "Select .adsky file" else "Change container",
                                icon = Icons.Rounded.FileOpen,
                                onClick = { containerPicker.launch(arrayOf("*/*")) },
                                modifier = Modifier.fillMaxWidth().testTag("select_container_button")
                            )
                        }
                    }
                }
            }

            // 2 ─ Public header details (private metadata stays sealed until authenticated)
            if (header != null) {
                item(key = "header") {
                    val isSigned = (header.flags.toInt() and ContainerConstants.FLAG_IS_SIGNED.toInt()) != 0
                    Surface(
                        Modifier.fillMaxWidth().animateItem().testTag("inspected_header_card"),
                        shape = RoundedCornerShape(32.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                    ) {
                        Column(Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ShapeBadge(
                                    Icons.Rounded.Shield, polygon = MaterialShapes.Clover4Leaf, size = 44.dp,
                                    containerColor = MaterialTheme.colorScheme.secondary,
                                    contentColor = MaterialTheme.colorScheme.onSecondary
                                )
                                Spacer(Modifier.width(14.dp))
                                Text("Structure validated", style = MaterialTheme.typography.titleMedium.emphasized(), modifier = Modifier.weight(1f))
                            }
                            Spacer(Modifier.size(8.dp))
                            KeyValueRow("Algorithm", header.algorithm.displayName)
                            KeyValueRow("Format version", "v${header.formatVersion}", monospace = true)
                            KeyValueRow("Generation", "#${header.generationNumber}", monospace = true)
                            KeyValueRow(
                                "Signature",
                                if (isSigned) "Signed (ECDSA P-256)" else "Unsigned",
                                valueColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(Modifier.size(10.dp))
                            Text("Available envelopes", style = MaterialTheme.typography.labelLarge.emphasized())
                            Spacer(Modifier.size(6.dp))
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                inspectedEnvelopes.forEach { env ->
                                    InfoChip(env, containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }
                }

                // 3 ─ Authorization method
                item(key = "auth") {
                    val hasDevice = header.envelopes.any { it.envelopeType == ContainerConstants.ENVELOPE_DEVICE_KEYSTORE }
                    val hasCred = header.envelopes.any { it.envelopeType == ContainerConstants.ENVELOPE_CUSTOM_CREDENTIAL }
                    val hasRecovery = header.envelopes.any { it.envelopeType == ContainerConstants.ENVELOPE_RECOVERY_SECRET }
                    val count = listOf(hasDevice, hasCred, hasRecovery).count { it }
                    var index = 0

                    Column(Modifier.animateItem().testTag("auth_mode_card"), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SectionHeader("Authorization", step = 2, subtitle = "Pick how to unlock this container.")
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            if (hasDevice) {
                                RadioOptionRow(
                                    selected = authMode == DecryptAuthMode.DEVICE_KEYSTORE,
                                    onClick = { viewModel.setDecryptAuthMode(DecryptAuthMode.DEVICE_KEYSTORE) },
                                    title = "Original-device Keystore",
                                    description = "Unlocks automatically with this phone's Keystore master key.",
                                    shape = connectedShape(index++, count)
                                )
                            }
                            if (hasCred) {
                                RadioOptionRow(
                                    selected = authMode == DecryptAuthMode.CUSTOM_CREDENTIAL,
                                    onClick = { viewModel.setDecryptAuthMode(DecryptAuthMode.CUSTOM_CREDENTIAL) },
                                    title = "PIN or passphrase",
                                    description = "Derives the key with the Argon2id parameters stored in the header.",
                                    shape = connectedShape(index++, count)
                                )
                            }
                            if (hasRecovery) {
                                RadioOptionRow(
                                    selected = authMode == DecryptAuthMode.RECOVERY_SECRET,
                                    onClick = { viewModel.setDecryptAuthMode(DecryptAuthMode.RECOVERY_SECRET) },
                                    title = "Master recovery secret",
                                    description = "Use the secret from the original install, or one transferred from another device.",
                                    shape = connectedShape(index++, count)
                                )
                            }
                        }

                        AnimatedVisibility(
                            visible = authMode == DecryptAuthMode.CUSTOM_CREDENTIAL && hasCred,
                            enter = expandVertically(motion.defaultSpatialSpec()) + fadeIn(motion.defaultEffectsSpec()),
                            exit = shrinkVertically(motion.fastSpatialSpec()) + fadeOut(motion.fastEffectsSpec())
                        ) {
                            Surface(Modifier.fillMaxWidth().padding(top = 6.dp), shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                                Column(Modifier.padding(20.dp)) {
                                    SecretTextField(
                                        value = credentialInput,
                                        onValueChange = { viewModel.setDecryptCredentialInput(it) },
                                        label = "PIN or passphrase",
                                        modifier = Modifier.testTag("input_decrypt_credential")
                                    )
                                }
                            }
                        }
                        AnimatedVisibility(
                            visible = authMode == DecryptAuthMode.RECOVERY_SECRET && hasRecovery,
                            enter = expandVertically(motion.defaultSpatialSpec()) + fadeIn(motion.defaultEffectsSpec()),
                            exit = shrinkVertically(motion.fastSpatialSpec()) + fadeOut(motion.fastEffectsSpec())
                        ) {
                            Surface(Modifier.fillMaxWidth().padding(top = 6.dp), shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                                Column(Modifier.padding(20.dp)) {
                                    SecretTextField(
                                        value = recoverySecretInput,
                                        onValueChange = { viewModel.setDecryptRecoverySecretInput(it) },
                                        label = "Recovery secret (ADSKY-…)",
                                        placeholder = "ADSKY-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX",
                                        obscured = false,
                                        modifier = Modifier.testTag("input_decrypt_recovery_secret")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Feedback
            if (errorMessage != null) {
                item(key = "error") {
                    StatusBanner(
                        kind = BannerKind.Error,
                        message = errorMessage.orEmpty(),
                        modifier = Modifier.animateItem().testTag("decryption_error_box")
                    )
                }
            }
            val result = decryptedResult
            if (result != null) {
                item(key = "result") {
                    ResultCard(
                        title = "Decrypted & verified",
                        lines = listOf(
                            result.metadata.originalFilename,
                            "${Formatter.formatFileSize(context, result.metadata.originalByteCount)} · ${result.metadata.mimeType}"
                        ),
                        badge = if (result.signatureVerified) "Signature verified: ${result.signerIdentity}" else null,
                        actionText = "Save decrypted file",
                        actionIcon = Icons.Rounded.SaveAlt,
                        onAction = { saveFileLauncher.launch(result.metadata.originalFilename) },
                        cardTag = "decryption_result_card",
                        actionTag = "save_decrypted_file_button",
                        modifier = Modifier.animateItem()
                    )
                }
            }
        }
    }
}
